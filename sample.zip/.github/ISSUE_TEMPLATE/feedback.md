---
name: Feedback
about: Share feedback with the Uno team 💖
labels: kind/feedback, triage/untriaged
---

<!-- Thanks for stopping on by to share feedback 💖

If you are after inspiration, folks typically submit feedback on the following topics:

- what version of Uno and what platforms you are using it with?
- what do you like?
- what is lacking?
- what do you long for going forward?
- where and how you have used Uno in production?
- any friction that hinders adoption of Uno at your company.
- any friction that's preventing you from contributing to Uno.

If you are representing an organization that wishes to discuss in private, please [contact us](https://platform.uno/contact/).

-->

