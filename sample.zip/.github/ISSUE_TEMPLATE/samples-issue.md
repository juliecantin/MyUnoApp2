---
name: Samples Issue
about: Report an issue with the Uno samples
labels: kind/contributor-experience, kind/documentation, triage/untriaged
---

<!-- Please only use this template for reporting issues with the samples where the fix isn't clear. We greatly appreciate it when people send in pull-requests with fixes. If there's any friction, apart from knowledge, that's preventing you from doing so please let us know below. -->

## On which page?

## What's wrong?

## Any feedback?

